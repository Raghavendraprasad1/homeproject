<?php
$con=mysqli_connect("localhost","root","","protech");
if(!$con){
	die("connection failed :". mysqli_connect_error());
}

?>